﻿namespace CRMProject.Models
{
    public enum MembershipTypeName
    {
        LocalIndustrial,
        NonLocalIndustrial,
        InKind,
        GovernmentAndEducation,
        Chamber,
        Associate
    }

}
