﻿namespace CRMProject.Models
{
    public class MemberMembershipType
    {
        
    }
}
