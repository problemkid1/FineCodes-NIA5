﻿namespace CRMProject.Models
{
    public enum EmailType
    {
        VIP,
        Work,
        Personal
    }
}
