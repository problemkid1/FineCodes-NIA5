﻿namespace CRMProject.Models
{
    public enum MemberStatus
    {
        GoodStanding,
        OverduePayment,
        Canceled,
        Expired
    }

}
