﻿namespace CRMProject.Models
{
    public enum OpportunityStatus
    {
        Qualification,
        Negotiating,
        ClosedNewMember,
        ClosedNotInterested
    }

}
