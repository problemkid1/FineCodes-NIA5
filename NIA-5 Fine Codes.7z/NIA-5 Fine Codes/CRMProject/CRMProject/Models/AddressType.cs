﻿namespace CRMProject.Models
{
    public enum AddressType
    {
        Headquarters,
        Branch,
        Warehouse
    }
}
